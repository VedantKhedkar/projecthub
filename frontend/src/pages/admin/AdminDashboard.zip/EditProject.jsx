import React, { useState, useEffect, useContext } from "react";
import { Upload, Save } from "lucide-react";
import AuthContext from "../../context/AuthContext";
import { useNavigate, useParams } from "react-router-dom";

const EditProject = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user } = useContext(AuthContext);

  const [form, setForm] = useState({
    title: "",
    price: "",
    category: "MERN Stack",
    techStack: "",
    description: "",
    thumbnail: null,
    sourceCode: null,
    assets: null,
  });

  const [loading, setLoading] = useState(true);
  const [previewImage, setPreviewImage] = useState("");

  // Fetch existing project
  useEffect(() => {
    const fetchProject = async () => {
      try {
        const res = await fetch(`/api/projects/${id}`);
        const data = await res.json();

        setForm({
          title: data.title,
          price: data.price,
          category: data.category,
          techStack: data.techStack.join(", "),
          description: data.description,
          thumbnail: null,
          sourceCode: null,
          assets: null,
        });

        setPreviewImage(data.image);

        setLoading(false);
      } catch (error) {
        console.error("Error loading project:", error);
      }
    };

    fetchProject();
  }, [id]);

  const handleInput = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleFile = (e) => {
    const file = e.target.files[0];

    if (e.target.name === "thumbnail") {
      setPreviewImage(URL.createObjectURL(file));
    }

    setForm({ ...form, [e.target.name]: file });
  };

  const submit = async () => {
    const formData = new FormData();
    formData.append("title", form.title);
    formData.append("price", form.price);
    formData.append("category", form.category);
    formData.append("techStack", form.techStack);
    formData.append("description", form.description);

    if (form.thumbnail) formData.append("thumbnail", form.thumbnail);
    if (form.sourceCode) formData.append("sourceCode", form.sourceCode);
    if (form.assets) formData.append("assets", form.assets);

    const res = await fetch(`/api/projects/${id}`, {
      method: "PATCH",
      headers: {
        Authorization: `Bearer ${user.token}`,
      },
      body: formData,
    });

    const data = await res.json();

    if (res.ok) {
      alert("Project updated successfully!");
      navigate(`/project/${id}`);
    } else {
      alert(data.message);
    }
  };

  if (loading)
    return (
      <div className="flex justify-center py-20">
        <p>Loading...</p>
      </div>
    );

  return (
    <div className="max-w-4xl mx-auto bg-white rounded-3xl p-10 shadow-md border border-gray-100 space-y-6">

      <h1 className="text-3xl font-black">Edit Project</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <input
          type="text"
          name="title"
          placeholder="Project Title"
          value={form.title}
          onChange={handleInput}
          className="border p-3 rounded-xl"
        />

        <input
          type="number"
          name="price"
          placeholder="Price"
          value={form.price}
          onChange={handleInput}
          className="border p-3 rounded-xl"
        />

        <select
          name="category"
          value={form.category}
          onChange={handleInput}
          className="border p-3 rounded-xl"
        >
          <option>MERN Stack</option>
          <option>Full Stack</option>
          <option>Frontend</option>
          <option>Backend</option>
          <option>AI/ML</option>
        </select>

        <input
          type="text"
          name="techStack"
          placeholder="Tech Stack (comma separated)"
          value={form.techStack}
          onChange={handleInput}
          className="border p-3 rounded-xl"
        />
      </div>

      <textarea
        name="description"
        placeholder="Description"
        value={form.description}
        onChange={handleInput}
        rows="4"
        className="border p-3 rounded-xl w-full"
      />

      {/* Files */}
      <h2 className="font-bold">Project Files</h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">

        {/* Thumbnail */}
        <label className="border-2 border-dashed rounded-xl p-6 text-center cursor-pointer hover:bg-gray-50">
          <Upload className="mx-auto" />
          <p className="mt-2">Thumbnail Image</p>
          <input type="file" name="thumbnail" className="hidden" onChange={handleFile} />
          {previewImage && (
            <img src={previewImage} className="w-full h-32 object-cover mt-3 rounded-xl" />
          )}
        </label>

        {/* Source Code */}
        <label className="border-2 border-dashed rounded-xl p-6 text-center cursor-pointer hover:bg-gray-50">
          <Upload className="mx-auto" />
          <p className="mt-2">Source Code (ZIP)</p>
          <input type="file" name="sourceCode" className="hidden" onChange={handleFile} />
        </label>

        {/* Assets */}
        <label className="border-2 border-dashed rounded-xl p-6 text-center cursor-pointer hover:bg-gray-50">
          <Upload className="mx-auto" />
          <p className="mt-2">Assets / Setup</p>
          <input type="file" name="assets" className="hidden" onChange={handleFile} />
        </label>
      </div>

      <button
        onClick={submit}
        className="mt-6 w-full md:w-auto px-6 py-3 bg-primary text-white rounded-xl font-bold flex items-center gap-2"
      >
        <Save size={20} /> Save Changes
      </button>
    </div>
  );
};

export default EditProject;
