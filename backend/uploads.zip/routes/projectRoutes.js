// routes/projectRoutes.js

import express from "express";
import {
  getProjects,
  getProjectById,
  createProject,
  updateProject,
  deleteProject,
} from "../controllers/projectController.js";

import { protect, admin } from "../middleware/authMiddleware.js";
import multer from "multer";

const router = express.Router();

// ========= MULTER FILE UPLOAD SETUP =========
const upload = multer({
  dest: "uploads/",
});

// ========= ROUTES =========

// GET all + CREATE project (Admin)
router
  .route("/")
  .get(getProjects)
  .post(
    protect,
    admin,
    upload.fields([
      { name: "thumbnail", maxCount: 1 },
      { name: "sourceCode", maxCount: 1 },
      { name: "assets", maxCount: 1 },
    ]),
    createProject
  );

// GET single project + UPDATE + DELETE (Admin)
router
  .route("/:id")
  .get(getProjectById)
  .patch(
    protect,
    admin,
    upload.fields([
      { name: "thumbnail", maxCount: 1 },
      { name: "sourceCode", maxCount: 1 },
      { name: "assets", maxCount: 1 },
    ]),
    updateProject
  )
  .delete(protect, admin, deleteProject);

export default router;
