// controllers/projectController.js

import asyncHandler from "express-async-handler";
import PrebuiltProject from "../models/PrebuiltProject.js";

// =============================================
// GET ALL PROJECTS
// GET /api/projects
// =============================================
export const getProjects = asyncHandler(async (req, res) => {
  const keyword = req.query.keyword
    ? {
        title: {
          $regex: req.query.keyword,
          $options: "i", // case insensitive
        },
      }
    : {};

  const projects = await PrebuiltProject.find({ ...keyword });
  res.json(projects);
});

// =============================================
// GET SINGLE PROJECT
// GET /api/projects/:id
// =============================================
export const getProjectById = asyncHandler(async (req, res) => {
  const project = await PrebuiltProject.findById(req.params.id);

  if (project) {
    res.json(project);
  } else {
    res.status(404);
    throw new Error("Project not found");
  }
});

// =============================================
// CREATE PROJECT (ADMIN ONLY)
// POST /api/projects
// =============================================
export const createProject = asyncHandler(async (req, res) => {
  const { title, category, price, description, techStack, demoLink, image } = req.body;

  const project = new PrebuiltProject({
    title,
    category,
    price,
    description,
    techStack,    // Array: ["React", "Node"]
    demoLink,
    image,
  });

  const createdProject = await project.save();
  res.status(201).json(createdProject);
});
export const updateProject = asyncHandler(async (req, res) => {
  const project = await PrebuiltProject.findById(req.params.id);

  if (!project) {
    res.status(404);
    throw new Error("Project not found");
  }

  // Update text fields
  project.title = req.body.title || project.title;
  project.price = req.body.price || project.price;
  project.category = req.body.category || project.category;
  project.description = req.body.description || project.description;

  if (req.body.techStack)
    project.techStack = req.body.techStack.split(",").map((t) => t.trim());

  // Update files only if uploaded
  if (req.files?.thumbnail) {
    project.image = `/uploads/${req.files.thumbnail[0].filename}`;
  }

  if (req.files?.sourceCode) {
    project.sourceCode = `/uploads/${req.files.sourceCode[0].filename}`;
  }

  if (req.files?.assets) {
    project.assets = `/uploads/${req.files.assets[0].filename}`;
  }

  const updated = await project.save();
  res.json(updated);
});
export const deleteProject = asyncHandler(async (req, res) => {
  const project = await PrebuiltProject.findById(req.params.id);

  if (!project) {
    res.status(404);
    throw new Error("Project not found");
  }

  await project.deleteOne();

  res.json({ message: "Project deleted successfully" });
});

